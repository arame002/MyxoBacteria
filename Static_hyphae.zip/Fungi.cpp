//
//  Fungi.cpp
//  Myxobacteria
//
//  Created by Alireza Ramezani on 11/19/20.
//  Copyright © 2020 Alireza Ramezani. All rights reserved.
//

#include "Fungi.hpp"
void Fungi::Find_Hyphae_Tips()
{
    tips.resize(2) ;
    for (uint i=0 ; i<hyphaeSegments.size() ; i++)
    {
        if (hyphaeSegments[i].can_extend == true)
        {
            tips[0].push_back(hyphaeSegments[i].x2) ;
            tips[1].push_back(hyphaeSegments[i].y2) ;
        }
    }
}
