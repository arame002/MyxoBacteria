//
//  driver.h
//  Myxobacteria
//
//  Created by Alireza Ramezani on 11/12/20.
//  Copyright © 2020 Alireza Ramezani. All rights reserved.
//

#ifndef driver_h
#define driver_h


#include "Fungi.hpp"


Fungi driver () ;


#endif /* driver_h */
